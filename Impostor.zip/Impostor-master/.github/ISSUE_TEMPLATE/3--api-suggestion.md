---
name: 3. Api suggestion
about: To make suggestions for the plugin api
title: ''
labels: api
assignees: ''

---

# Api Suggestion

## Suggestion
<!--
Describe your suggestion as detailed as possible.
-->

## Use case
<!--
Describe what you need it for.
-->
