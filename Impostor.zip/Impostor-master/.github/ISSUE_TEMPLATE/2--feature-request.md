---
name: 2. Feature request
about: To ask and request new features with Impostor
title: ''
labels: ''
assignees: ''

---

# Feature Request

## Feature Information:
<!--
 - One issue per post! Do not try and bring up multiple requests in a single post.
 - What should it do?
-->

## I confirm:
- [ ] that I have searched for an existing feature request matching the description.
