---
name: 5. Api unavailable data
about: To let us know about unavailable data from the api that you would like to use
title: ''
labels: api
assignees: ''

---

# Api missing data

## Data
<!--
Describe about the unavailable data that you need.
-->

## Use-case
<!--
Describe what you need it for.
-->
