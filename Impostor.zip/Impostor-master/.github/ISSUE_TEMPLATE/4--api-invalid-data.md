---
name: 4. Api invalid data
about: To let us know about invalid data in the api
title: ''
labels: api
assignees: ''

---

# Api missing data

## Data
<!--
Describe about the missing data that you need.
-->

## Expectations
<!--
Describe what the api gave you and what you expected.
-->

## Reproduce
<!--
Describe how to reproduce the issue.
-->
