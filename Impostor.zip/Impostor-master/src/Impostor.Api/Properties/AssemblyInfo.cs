﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Impostor.Server")]
