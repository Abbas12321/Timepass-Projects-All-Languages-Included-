namespace Impostor.Api.Innersloth
{
    public enum QuickChatModes
    {
        FreeChatOrQuickChat = 1,
        QuickChatOnly = 2,
    }
}
