namespace Impostor.Api.Innersloth
{
    public enum Language
    {
        English,
        SpanishLA,
        Brazilian,
        Portuguese,
        Korean,
        Russian,
        Dutch,
        Filipino,
        French,
        German,
        Italian,
        Japanese,
        SpanishEU,
    }
}
