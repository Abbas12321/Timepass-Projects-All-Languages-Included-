﻿namespace Impostor.Api.Innersloth
{
    public enum MapTypes : byte
    {
        Skeld = 0,
        MiraHQ = 1,
        Polus = 2,
        Airship = 4,
    }
}
