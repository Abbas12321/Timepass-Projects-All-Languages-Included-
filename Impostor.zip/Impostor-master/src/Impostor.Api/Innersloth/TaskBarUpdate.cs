﻿namespace Impostor.Api.Innersloth
{
    public enum TaskBarUpdate : byte
    {
        Always = 0,
        Meetings = 1,
        Never = 2,
    }
}
