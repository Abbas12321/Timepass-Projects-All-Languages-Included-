﻿namespace Impostor.Api.Innersloth
{
    public enum GameStates : byte
    {
        NotStarted = 0,
        Starting = 1,
        Started = 2,
        Ended = 3,
        Destroyed = 4,
    }
}
