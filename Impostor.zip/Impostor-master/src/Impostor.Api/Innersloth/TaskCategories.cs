namespace Impostor.Api.Innersloth
{
    public enum TaskCategories : byte
    {
        CommonTask,
        LongTask,
        ShortTask,
    }
}
