﻿namespace Impostor.Api.Events.Player
{
    public interface IPlayerSpawnedEvent : IPlayerEvent
    {
    }
}
