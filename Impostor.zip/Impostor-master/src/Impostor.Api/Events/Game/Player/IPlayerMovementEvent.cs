namespace Impostor.Api.Events.Player
{
    public interface IPlayerMovementEvent : IPlayerEvent
    {
    }
}
