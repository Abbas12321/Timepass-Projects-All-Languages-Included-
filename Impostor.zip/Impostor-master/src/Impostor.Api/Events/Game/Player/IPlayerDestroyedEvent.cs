﻿namespace Impostor.Api.Events.Player
{
    public interface IPlayerDestroyedEvent : IPlayerEvent
    {
    }
}
