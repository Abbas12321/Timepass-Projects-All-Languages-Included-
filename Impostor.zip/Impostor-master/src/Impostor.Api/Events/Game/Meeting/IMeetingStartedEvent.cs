﻿namespace Impostor.Api.Events.Meeting
{
    public interface IMeetingStartedEvent : IMeetingEvent
    {
    }
}
