﻿namespace Impostor.Api.Events
{
    public interface IEvent
    {
    }
}
