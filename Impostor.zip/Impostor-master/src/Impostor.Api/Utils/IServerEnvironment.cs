namespace Impostor.Api.Utils
{
    public interface IServerEnvironment
    {
        string Version { get; }
    }
}
