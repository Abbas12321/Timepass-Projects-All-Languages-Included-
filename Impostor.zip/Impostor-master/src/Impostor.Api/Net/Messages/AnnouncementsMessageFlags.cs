namespace Impostor.Api.Net.Messages
{
    public class AnnouncementsMessageFlags
    {
        public const byte UseCache = 0;
        public const byte SetUpdate = 1;
        public const byte AddLanguages = 4;
    }
}
