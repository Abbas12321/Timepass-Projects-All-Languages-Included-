namespace Impostor.Api.Net.Messages.Rpcs
{
    public static class Rpc04Exiled
    {
        public static void Serialize(IMessageWriter writer)
        {
        }

        public static void Deserialize(IMessageReader reader)
        {
        }
    }
}
