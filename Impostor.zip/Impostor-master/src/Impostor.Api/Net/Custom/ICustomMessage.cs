namespace Impostor.Api.Net.Custom
{
    public interface ICustomMessage
    {
        byte Id { get; }
    }
}
