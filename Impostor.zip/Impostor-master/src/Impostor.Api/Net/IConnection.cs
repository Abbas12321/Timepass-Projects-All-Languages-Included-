﻿namespace Impostor.Api.Net
{
    public interface IConnection
    {
    }
}
