﻿namespace Impostor.Api.Net.Inner.Objects.Components
{
    public interface IInnerPlayerPhysics : IInnerNetObject
    {
    }
}
