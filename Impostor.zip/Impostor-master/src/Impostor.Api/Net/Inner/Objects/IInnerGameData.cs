﻿namespace Impostor.Api.Net.Inner.Objects
{
    public interface IInnerGameData : IInnerNetObject
    {
    }
}
