﻿namespace Impostor.Api.Net.Inner.Objects.ShipStatus
{
    public interface IInnerMiraShipStatus : IInnerShipStatus
    {
    }
}
