﻿namespace Impostor.Api.Plugins
{
    public enum DependencyType
    {
        HardDependency,
        SoftDependency,
        LoadBefore,
    }
}
