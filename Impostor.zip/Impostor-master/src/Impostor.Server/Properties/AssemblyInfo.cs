﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Impostor.Benchmarks")]
[assembly: InternalsVisibleTo("Impostor.Tests")]
[assembly: InternalsVisibleTo("Impostor.Tools.ServerReplay")]
