﻿namespace Impostor.Server.Net.Inner.Objects.Systems
{
    public interface IActivatable
    {
        bool IsActive { get; }
    }
}
