using Impostor.Api.Plugins;

namespace Impostor.Plugins.Debugger
{
    [ImpostorPlugin("gg.impostor.debugger")]
    public class DebugPlugin : PluginBase
    {
    }
}
