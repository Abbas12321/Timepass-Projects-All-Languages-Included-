var queue = [
  "http://www.xiachufang.com/category/40076/",
  "http://www.xiachufang.com/category/40077/",
  "http://www.xiachufang.com/category/40078/",
  "http://www.xiachufang.com/category/51848/",
  "http://www.xiachufang.com/category/51761/",
  "http://www.xiachufang.com/category/20135/"
];

  // "http://www.xiachufang.com/category/"

module.exports = queue;
